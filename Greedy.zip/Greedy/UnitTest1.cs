﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Datavalidation;
namespace UnitTest
{
    [TestClass]
    //没有涉及到每个种类的全部 但每个种类都有涉及到
    public class UnitTest1
    {
        [TestMethod]
        public void TestTaskRuntime()
        { // Arrange.
            double expectedT1runtime =7.407407;
            // Act.
            Form1 form = new Form1();

            // Assert.
            Assert.AreEqual(form.runtimep1, expectedT1runtime, "the amount of energy per second is incorrect");


        }
        [TestMethod]
        public void TestTaskEnergyConsumption()
        {// Arrange.
            double expectedT1EnergyConsumption = 170;
            // Act.
            Form1 form = new Form1();

            // Assert.
            Assert.AreEqual(form.Econsumption, expectedT1EnergyConsumption, "the amount of energy per second is incorrect");



        }
        [TestMethod]
        public void TestAllocationRuntime()
        {
            // Arrange.
            double expectedTruntime = 2.3529;
            // Act.
            Form1 form = new Form1();

            // Assert.
            Assert.AreEqual(form.runtime, expectedTruntime, "the amount of energy per second is incorrect");
        }
        [TestMethod]
        public void TestAllcationEnergyConsumption()
        {
            // Arrange.
            double expectedEnergyConsumption = 170;
            // Act.
            Form1 form = new Form1();

            // Assert.
            Assert.AreEqual(form.Econsumption, expectedEnergyConsumption, "the amount of energy per second is incorrect");
        }
        [TestMethod]
        public void TestAllocation()
        {// Arrange.
            double expectedtanunvalid = 0;
            // Act.
            Form1 form = new Form1();

            // Assert.
            Assert.AreEqual(form.errortanallocation, expectedtanunvalid, "the amount of energy per second is incorrect");

        }
        [TestMethod]
        //csv file
        public void TestConfigurationFile()
        {   // Arrange.
            double expectedcsvunvalid = 0;
            // Act.
            Form1 form = new Form1();

            // Assert.
            Assert.AreEqual(form.errorcsv, expectedcsvunvalid, "the amount of energy per second is incorrect");

        }
        [TestMethod]
        //tan file
        public void TestAllocationFile()
        {   // Arrange.
            double expectedtanunvalid = 0;
            // Act.
            Form1 form = new Form1();
           
            // Assert.
            Assert.AreEqual(form.errortan, expectedtanunvalid, "the amount of energy per second is incorrect");
            
        }
    }
}
