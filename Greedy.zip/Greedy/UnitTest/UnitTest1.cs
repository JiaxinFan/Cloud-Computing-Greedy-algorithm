﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Datavalidation;
namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestTaskRuntime()
        {
        }
        [TestMethod]
        public void TestTaskEnergyConsumption()
        {
        }
        [TestMethod]
        public void TestAllocationRuntime()
        {
        }
        [TestMethod]
        public void TestAllcationEnergyConsumption()
        {
        }
        [TestMethod]
        public void TestAllocation()
        {
        }
        [TestMethod]
        //csv file
        public void TestConfigurationFile()
        {
           
        }
        [TestMethod]
        //tan file
        public void TestAllocationFile()
        {   // Arrange.
            double expectedtanunvalid = 0;
            // Act.
            Form1 form = new Form1();
            // Assert.
            Assert.AreEqual(form.errortan, expectedtanunvalid, "the amount of energy per second is incorrect");
            
        }
    }
}
