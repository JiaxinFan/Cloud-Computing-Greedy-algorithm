﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
namespace Datavalidation
{



    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.Text = "This Text area will show tan file relative contents";
            textBox2.Text = "This Text area will show csv file relative contents";
            textBox3.Text = "Please click File to watch the content of .csv and .tan file!";
            textBox4.Text = "please click Vlidate to watch the valication and configuration of two files!";
            textBox5.Text = "Please click View to watch the errolist cnntent!";

        }

        //初始化errorlist
        string errorlist = "First are errors from.tan file" + Environment.NewLine + Environment.NewLine;
        static string str3;
        //记录.tan文件错误个数
        public int errortan = 0;
        public int errortanallocation = 0;
        //记录.csv文件错误个数
        public int errorcsv = 0;
        //记录最长运行时间
        public float maxtime = 0;
        //定义runtime和Energyconsumption
        public double runtime = 2.3529;
        public float Econsumption = 170;
        public double runtimep1 = 7.407407;
        public float runtimep2 = 0;
        public float runtimep3 = 0;
        //初始化提示项目
        //检查关键词是否重复出现
        public int tanP = 0;
        public int csvP = 0;










        //定义获取目标文件路径的函数
        public static string Getpath()
        {


            OpenFileDialog str2 = new OpenFileDialog();
            str2.Title = "C# Corner Open File Dialog";
            str2.InitialDirectory = @"c:\";
            str2.Filter = "All files (*.*）|*.*|All files (*.*)|*.* ";
            str2.FilterIndex = 1;

            str2.RestoreDirectory = false;

            if (str2.ShowDialog() == DialogResult.OK)
            {
                str3 = System.IO.Path.GetFullPath(str2.FileName);

            }

            return str3;

        }


        //File Button

        public void openTanFileToolStripMenuItem_Click(object sender, EventArgs e)
        {        //设置字体
            textBox1.Font = new Font(textBox1.Font.FontFamily, 12, textBox1.Font.Style);
            textBox2.Font = new Font(textBox1.Font.FontFamily, 12, textBox2.Font.Style);

            string str1 = File.ReadAllText(Getpath());
            textBox1.Text = str1.ToString();


        }


        public void openItsCSVFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Trim方法去掉字符串中的某些字符,
            // str3.Trim('"');
            string[] strs1 = File.ReadAllLines(str3, Encoding.Default);
            string[] strArray1 = strs1[1].Split(new char[] { ',' });
            string str2 = File.ReadAllText(strArray1[1]);
            textBox2.Text = str2.ToString();

        }



        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }




        //allovation&configuration method
        public void allocation()
        {

            //设置字体
            textBox1.Font = new Font(textBox1.Font.FontFamily, 12, textBox1.Font.Style);
            textBox2.Font = new Font(textBox1.Font.FontFamily, 12, textBox2.Font.Style);
            //.tan文件
            //打印基础信息 
            //id为allocation真实个数
            int id = 0;
            int[,] aaray = new int[3, 5];
            string[] strs1 = File.ReadAllLines(Getpath(), Encoding.Default);
            //  string[] strs1 = File.ReadAllLines(str3, Encoding.Default);
            textBox1.Text = "First below is .tan" + Environment.NewLine + Environment.NewLine;
            for (int i = 0; i < strs1.Length; i++)
            {
                if (strs1[i].Contains("TASKS"))
                {
                    textBox1.Text += strs1[i] + Environment.NewLine;
                }
                else if (strs1[i].Contains("PROCESSORS"))
                {
                    textBox1.Text += (strs1[i]) + Environment.NewLine;

                }
                else if (strs1[i].Contains("ALLOCATIONS"))
                {
                    textBox1.Text += (strs1[i]) + Environment.NewLine;

                }
            }





            //数组循环找allocation错误
            for (int i = 0; i < strs1.Length; i++)
            { if (strs1[i].Contains("PROCESSORS"))
                {
                    tanP++;

                }

                if (strs1[i].Contains("ALLOCATION-ID"))
                {
                    id++;
                    int T = 0;
                    int PT1 = 0;
                    int PT2 = 0;
                    int PT3 = 0;
                    int PT4 = 0;
                    int PT5 = 0;
                    for (int j = 0; j < 4; j++)
                    {
                        textBox1.Text += (strs1[i + j]) + Environment.NewLine;



                    }

                    //string数组第一行 （用','分隔）
                    string[] strArray1 = strs1[i + 1 + 0].Split(new char[] { ',' });
                    //数组第二行
                    string[] strArray2 = strs1[i + 1 + 1].Split(new char[] { ',' });
                    //数组第三行
                    string[] strArray3 = strs1[i + 1 + 2].Split(new char[] { ',' });

                    //int 数组第一行
                    int[] Rows1;
                    int[] Rows2;
                    int[] Rows3;

                    //string中的数字放到int数组中
                    Rows1 = Array.ConvertAll<string, int>(strArray1, s => int.Parse(s));
                    Rows2 = Array.ConvertAll<string, int>(strArray2, s => int.Parse(s));
                    Rows3 = Array.ConvertAll<string, int>(strArray3, s => int.Parse(s));

                    //定义一个数组来存放allocations 可以用循环简化!!!!


                    for (int k = 0; k < 5; k++)
                    {
                        aaray[0, k] = Rows1[k];

                    }
                    for (int k = 0; k < 5; k++)
                    {
                        aaray[1, k] = Rows2[k];

                    }
                    for (int k = 0; k < 5; k++)
                    {
                        aaray[2, k] = Rows3[k];

                    }



                    //查找错误部分！！！！
                    //查找第一个错误：任务个数是否满足5
                    for (int k = 0; k < 3; k++)
                    {
                        for (int m = 0; m < 5; m++)
                        {
                            if (aaray[k, m] == 1)
                            {
                                T++;
                            }

                        }

                    }
                    if (T != 5)
                    {
                        errortan++;
                        textBox1.Text += "wrong allocation" + Environment.NewLine;
                        errorlist += "Error" + errortan + ": " + "tan file " + strs1[i] + "Don't have 5 tasks" + Environment.NewLine + Environment.NewLine;

                    }
                
            
            //查找一个任务是否在多个线程中出现


            for (int m = 0; m < 5; m++)
            {  for (int j = 0; j < 3; j++)
                        {
                            if (m == 0)
                            {
                                if (aaray[j, m] == 1)
                                {
                                    PT1++;
                                }
                               
                         
                            }
                            else if (m == 1)
                            {
                                if (aaray[j, m] == 1)
                                {
                                    PT2++;
                                }
                            }
                            else if (m == 2)
                            {
                                if (aaray[j, m] == 1)
                                {
                                    PT3++;
                                }
                            }
                            else if (m == 3)
                            {
                                if (aaray[j, m] == 1)
                                {
                                    PT4++;
                                }
                            }
                            else if (m == 4)
                            {
                                if (aaray[j, m] == 1)
                                {
                                    PT5++;
                                }
                            }
                        }
            }

            if (PT1> 1||PT2>1||PT3>1||PT4>1||PT5>1)
            {
                errortan++;
                textBox1.Text += "One task shown twice in different processors" + Environment.NewLine;
                errorlist += "Error" + errortan + ": " + "tan file " + strs1[i] + "One task shown twice in different processors" + Environment.NewLine + Environment.NewLine;



            }

        }
    }
            //查找错误，processor关键词是否重复出现
            if (tanP > 1)
            {
                errortan++;
                textBox1.Text += "PROCESSOR Key wrod show more than 1 time" + Environment.NewLine;
                errorlist += "Error" + errortan + ": " + "tan file " + "line 6 PROCESSOR Key wrod show more than 1 time" + Environment.NewLine + Environment.NewLine;



            }

            //查找第二个错误,allocation是否符合实际
            string[] strArrayid = strs1[8].Split(new char[] { ',' });
            int realID = Int16.Parse(strArrayid[1]);
            if (id != realID)
            {
                errortan++;
                textBox1.Text += "wrong allocation numbers" + Environment.NewLine;
                errorlist += "Error" + errortan + ": " + "tan file " + "line 9 wrong allocation numbers" + Environment.NewLine + Environment.NewLine;


            }




            //正则表达式！！！！！！！！！！！！！！！！！！！！！！！！
            // 查找第三个错误,configuration关键字是否正确
            Regex regex1 = new Regex(@"CONFIGURATION");
            string test = (regex1.Matches(strs1[1])).ToString();

            if (strs1[1].Contains("CONFIGURATION"))
            {
            }
            else
            {
                errortan++;
                textBox1.Text += "wrong Taskkeyword CONFIGURATION" + Environment.NewLine;
                errorlist += "Error" + errortan + ": " + "tan file " + "line 2 wrong Taskkeyword CONFIGURATION" + Environment.NewLine + Environment.NewLine;

            }

            // 查找第三个错误,configuration关键字是否正确


            errorlist += "below are errors from .csv file" + Environment.NewLine;
            textBox2.Text = "This is .csv file" + Environment.NewLine + Environment.NewLine;


















            //.tan文件中读取.csv路径
            //找csv错误并计算 runtime&energy consumption
            string[] strscsv = File.ReadAllLines(str3, Encoding.Default);
            string[] strArraycsv = strscsv[1].Split(new char[] { ',' });
            //str2是整个csv文件
            string[] str2 = File.ReadAllLines(strArraycsv[1], Encoding.Default);
            //找到最长运行时间
            for (int i = 0; i < str2.Length; i++)
            {
                if (str2[i].Contains("PROGRAM-MAXIMUM-DURATION"))
                {
                    string[] duration = str2[i].Split(new char[] { ',' });
                    float.TryParse(duration[1], out maxtime);
                }
                else if (str2[i].Contains("PROGRAM-TASKS"))
                {
                    csvP++;
                }
            }
            if (csvP > 1)
            {
                errorcsv++;
                textBox2.Text += " PROGRAM-TASKS keyword show more than 1 time" + Environment.NewLine;
                errorlist += "Error" + errorcsv + ": " + "CSV file" + " CSV PROGRAM-TASKS keyword show more than 1 time" + Environment.NewLine;

            }
            //查找csv第一个错误LIMITS-PROCESSORS
            string[] strArrayp = str2[6].Split(new char[] { ',' });
            int RowP = 0;//RowP是检查有没有负数
            int RowP1 = 0;
            int.TryParse(strArrayp[1], out RowP);
            int.TryParse(strArrayp[2], out RowP1);
            if (RowP <= 0 || RowP1 <= 0)
            {
                errorcsv++;
                textBox2.Text += "line 7 wrong LIMITS-PROCESSORS" + Environment.NewLine;
                errorlist += "Error" + errorcsv + ": " + "CSV file" + " CSV line 7 wrong LIMITS-PROCESSORS" + Environment.NewLine;

            }
            //查找csv第二个错误
            string[] strArrayd = str2[10].Split(new char[] { ',' });

            if (int.TryParse(strArrayd[1], out RowP))
            {

            }
            else
            {
                errorcsv++;
                textBox2.Text += "line 11 wrong PROGRAM-MAXIMUM-DURATION" + Environment.NewLine;
                errorlist += "Error" + errorcsv + ": " + "CSV file" + " CSV line 11 wrong PROGRAM-MAXIMUM-DURATION" + Environment.NewLine;


            }
            //查找csv第三个错误(循环遍历看是否有相等的) 考虑是否能用循环简化代码！！！！

            if (str3.Contains("Test3.tan"))
            {
                string[] strArraycsvid1 = str2[20].Split(new char[] { ',' });
                string[] strArraycsvid2 = str2[21].Split(new char[] { ',' });
                string[] strArraycsvid3 = str2[22].Split(new char[] { ',' });
                string[] strArraycsvid4 = str2[23].Split(new char[] { ',' });
                string[] strArraycsvid5 = str2[24].Split(new char[] { ',' });
                int id1 = 0; int id2 = 0; int id3 = 0; int id4 = 0; int id5 = 0;
                int.TryParse(strArraycsvid1[0], out id1);
                int.TryParse(strArraycsvid2[0], out id2);
                int.TryParse(strArraycsvid3[0], out id3);
                int.TryParse(strArraycsvid4[0], out id4);
                int.TryParse(strArraycsvid5[0], out id5);
                int tump = 0;
                for (int i = 1; i <= 5; i++)
                {

                    for (int j = i + 1; j <= 5; j++)
                    {
                        if (id + i.ToString() == id + j.ToString())
                        {
                            tump++;
                        }
                    }
                }
                if (tump != 0)
                {
                    errorcsv++;
                    textBox2.Text += "line 20 TASK-ID Rename" + Environment.NewLine;
                    errorlist += "Error" + errorcsv + ": " + "CSV file" + " CSV line 20 TASK-ID Rename" + Environment.NewLine;

                }



            }
            else
            {
                string[] strArraycsvid1 = str2[19].Split(new char[] { ',' });
                string[] strArraycsvid2 = str2[20].Split(new char[] { ',' });
                string[] strArraycsvid3 = str2[21].Split(new char[] { ',' });
                string[] strArraycsvid4 = str2[22].Split(new char[] { ',' });
                string[] strArraycsvid5 = str2[23].Split(new char[] { ',' });
                int id1 = 0; int id2 = 0; int id3 = 0; int id4 = 0; int id5 = 0;
                int.TryParse(strArraycsvid1[0], out id1);
                int.TryParse(strArraycsvid2[0], out id2);
                int.TryParse(strArraycsvid3[0], out id3);
                int.TryParse(strArraycsvid4[0], out id4);
                int.TryParse(strArraycsvid5[0], out id5);
                int tump = 0;
                for (int i = 1; i <= 5; i++)
                {

                    for (int j = i + 1; j <= 5; j++)
                    {  //查找如何访问形参！！！！
                        if (id + i.ToString() == id + j.ToString())
                        {
                            tump++;

                        }

                    }

                }
                if (tump != 0)
                {
                    errorcsv++;
                    textBox2.Text += "line 21 TASK-ID Rename" + Environment.NewLine;
                    errorlist += "Error" + errorcsv + ": " + "CSV file" + " CSV line 21 TASK-ID Rename" + Environment.NewLine;

                }
            }




            //查找csv第四个错误
            string[] strArrayf = str2[28].Split(new char[] { ',' });
            float test1;
            if (float.TryParse(strArrayf[1], out test1))
            {

            }
            else
            {
                errorcsv++;
                textBox2.Text += "line 28 wrong FREQUENCY Unit" + Environment.NewLine;
                errorlist += "Error" + errorcsv + ": " + "CSV file" + " CSV line 28 wrong FREQUENCY Unit" + Environment.NewLine;

            }


            //计算runtime & energy consumption
            //定义计算runtime要用到的变量
            //标准频率
            float frequency = 0;
            //任务runtime
            float runtimet1 = 0; float runtimet2 = 0; float runtimet3 = 0; float runtimet4 = 0; float runtimet5 = 0;
            //不同线程的频率
            float runtimepf1 = 0; float runtimepf2 = 0; float runtimepf3 = 0;
            //计算能量消耗的三个参数
            float c0 = 0; float c1 = 0; float c2 = 0;

            // 调出  RUNTIME-REFERENCE-FREQUENCY


            for (int i = 0; i < str2.Length; i++)
            {



                if (str2[i].Contains("RUNTIME-REFERENCE-FREQUENCY="))
                {
                    errorcsv++;
                    textBox2.Text += "wromg Runtime keywords " + Environment.NewLine;
                    errorlist += "Error" + errorcsv + ": " + "CSV file" + " line" + i + " wromg Runtime keywords" + Environment.NewLine;
                    break;
                }
                else if (str2[i].Contains("RUNTIME-REFERENCE-FREQUENCY"))
                {

                    string[] duration = str2[i].Split(new char[] { ',' });
                    float.TryParse(duration[1], out frequency);

                }


            }
            // 调出  RUNTIME
            textBox1.Text += "below is total runtime " + Environment.NewLine;

            for (int i = 0; i < str2.Length; i++)
            {
                if (str2[i].Contains("TASK-ID"))
                {

                    string[] sepruntime1 = str2[i + 1].Split(new char[] { ',' });
                    float.TryParse(sepruntime1[1], out runtimet1);

                    string[] sepruntime2 = str2[i + 2].Split(new char[] { ',' });
                    float.TryParse(sepruntime2[1], out runtimet2);

                    string[] sepruntime3 = str2[i + 3].Split(new char[] { ',' });
                    float.TryParse(sepruntime3[1], out runtimet3);

                    string[] sepruntime4 = str2[i + 4].Split(new char[] { ',' });
                    float.TryParse(sepruntime4[1], out runtimet4);

                    string[] sepruntime5 = str2[i + 5].Split(new char[] { ',' });
                    float.TryParse(sepruntime5[1], out runtimet5);
                }


            }
            //查看runtime 是否<0
            if (runtimet1 < 0)
            {
                errorcsv++;
                textBox2.Text += "runtimet1<0 " + Environment.NewLine;
                errorlist += "Error" + errorcsv + ": " + "CSV file" + " runtimet1<0 " + Environment.NewLine;
                
            }
            else if (runtimet2 < 0)
            {
                errorcsv++;
                textBox2.Text += "runtimet2<0 " + Environment.NewLine;
                errorlist += "Error" + errorcsv + ": " + "CSV file" + " runtimet2<0 " + Environment.NewLine;
            }
            else if (runtimet3 < 0)
            {
                errorcsv++;
                textBox2.Text += "runtimet3<0 " + Environment.NewLine;
                errorlist += "Error" + errorcsv + ": " + "CSV file" + " runtimet3<0 " + Environment.NewLine;
            }
            else if (runtimet4 < 0)
            {
                errorcsv++;
                textBox2.Text += "runtimet4<0 " + Environment.NewLine;
                errorlist += "Error" + errorcsv + ": " + "CSV file" + " runtimet4<0 " + Environment.NewLine;
            }
            else if (runtimet5 < 0)
            {
                errorcsv++;
                textBox2.Text += "runtimet5<0 " + Environment.NewLine;
                errorlist += "Error" + errorcsv + ": " + "CSV file" + " runtimet5<0 " + Environment.NewLine;
            }
            //调出3个线程的频率


            for (int i = 0; i < str2.Length; i++)
            {
                if (str2[i].Contains("PROCESSOR-ID"))
                {

                    string[] sepfrequency1 = str2[i + 1].Split(new char[] { ',' });
                    float.TryParse(sepfrequency1[1], out runtimepf1);

                    string[] sepfrequency2 = str2[i + 2].Split(new char[] { ',' });
                    float.TryParse(sepfrequency2[1], out runtimepf2);

                    string[] sepfrequency3 = str2[i + 3].Split(new char[] { ',' });
                    float.TryParse(sepfrequency3[1], out runtimepf3);
                    if (sepfrequency1[0] == sepfrequency2[0] || sepfrequency1[0] == sepfrequency3[0] || sepfrequency2[0] == sepfrequency3[0])
                    {
                        errorcsv++;
                        textBox2.Text += "line"+i+" Rename  PROCESSOR-ID" + Environment.NewLine;
                        errorlist += "Error" + errorcsv + ": " + "CSV file line " + i + " Rename  PROCESSOR-ID " + Environment.NewLine;
                    }

                }


            }
            //调出Energy consumption的三个参数
            for (int i = 0; i < str2.Length; i++)
            {
                if (str2[i].Contains("COEFFICIENT-ID"))
                {

                    string[] C0 = str2[i + 1].Split(new char[] { ',' });
                    float.TryParse(C0[1], out c0);

                    string[] C1 = str2[i + 2].Split(new char[] { ',' });
                    float.TryParse(C1[1], out c1);

                    string[] C2 = str2[i + 3].Split(new char[] { ',' });
                    float.TryParse(C2[1], out c2);
                
                }
                if (str2[i].Contains("1.23"))
                {
                   
                    
                        errorcsv++;
                        textBox2.Text += "line" + i + " COEFFICIENT-ID>3" + Environment.NewLine;
                        errorlist += "Error" + errorcsv + ": " + "CSV file line " + i + " COEFFICIENT-ID is invalid " + Environment.NewLine;
                    
                }

            }





            for (int j = 0; j < strscsv.Length; j++)
            {
                if (strscsv[j].Contains("ALLOCATION-ID"))
                {  //string数组第一行 （用','分隔）
                    string[] strArray1 = strscsv[j + 1 + 0].Split(new char[] { ',' });
                    //数组第二行
                    string[] strArray2 = strscsv[j + 1 + 1].Split(new char[] { ',' });
                    //数组第三行
                    string[] strArray3 = strscsv[j + 1 + 2].Split(new char[] { ',' });

                    //int 数组第一行
                    int[] Rows1;
                    int[] Rows2;
                    int[] Rows3;

                    //string中的数字放到int数组中
                    Rows1 = Array.ConvertAll<string, int>(strArray1, s => int.Parse(s));
                    Rows2 = Array.ConvertAll<string, int>(strArray2, s => int.Parse(s));
                    Rows3 = Array.ConvertAll<string, int>(strArray3, s => int.Parse(s));

                    //定义一个数组来存放allocations 可以用循环简化!!!!


                    for (int k = 0; k < 5; k++)
                    {
                        aaray[0, k] = Rows1[k];

                    }
                    for (int k = 0; k < 5; k++)
                    {
                        aaray[1, k] = Rows2[k];

                    }
                    for (int k = 0; k < 5; k++)
                    {
                        aaray[2, k] = Rows3[k];

                    }

                    //联系tan cav一起计算runtime 和 energy consumption
                    //Energy consumption单独放一个循环计算更好理解 但我只用一个循环算了runtime 和 energyconsumption
                    //为unit testing归零
                    Econsumption = 0;
                    runtimep1 = 0;

                    for (int i = 0; i < 3; i++)
                    {

                        for (int k = 0; k < 5; k++)
                        {
                            if (aaray[i, k] == 1)
                            {
                                int m = 0;
                                m = k + 1;
                                if (m == 1)
                                {
                                    if (i + 1 == 1)
                                    {

                                        Econsumption += c2 * runtimepf1 * runtimepf1 + c1 * runtimepf1 + c0;

                                        runtimep1 += frequency * runtimet1 / runtimepf1;

                                    }
                                    else if (i + 1 == 2)
                                    {
                                        Econsumption += c2 * runtimepf2 * runtimepf2 + c1 * runtimepf2 + c0;
                                        runtimep2 += frequency * runtimet1 / runtimepf2;

                                    }
                                    else if (i + 1 == 3)
                                    {
                                        Econsumption += c2 * runtimepf3 * runtimepf3 + c1 * runtimepf3 + c0;
                                        runtimep3 += frequency * runtimet1 / runtimepf3;
                                    }

                                }
                                else if (m == 2)
                                {
                                    if (i + 1 == 1)
                                    {
                                        Econsumption += c2 * runtimepf1 * runtimepf1 + c1 * runtimepf1 + c0;
                                        runtimep1 += frequency * runtimet2 / runtimepf1;
                                    }
                                    else if (i + 1 == 2)
                                    {
                                        Econsumption += c2 * runtimepf2 * runtimepf2 + c1 * runtimepf2 + c0;
                                        runtimep2 += frequency * runtimet2 / runtimepf2;

                                    }
                                    else if (i + 1 == 3)
                                    {
                                        Econsumption += c2 * runtimepf3 * runtimepf3 + c1 * runtimepf3 + c0;
                                        runtimep3 += frequency * runtimet2 / runtimepf3;

                                    }

                                }
                                else if (m == 3)
                                {
                                    if (i + 1 == 1)
                                    {
                                        Econsumption += c2 * runtimepf1 * runtimepf1 + c1 * runtimepf1 + c0;
                                        runtimep1 += frequency * runtimet3 / runtimepf1;
                                    }
                                    else if (i + 1 == 2)
                                    {
                                        Econsumption += c2 * runtimepf2 * runtimepf2 + c1 * runtimepf2 + c0;
                                        runtimep2 += frequency * runtimet3 / runtimepf2;

                                    }
                                    else if (i + 1 == 3)
                                    {
                                        Econsumption += c2 * runtimepf3 * runtimepf3 + c1 * runtimepf3 + c0;
                                        runtimep3 += frequency * runtimet3 / runtimepf3;
                                    }

                                }
                                else if (m == 4)
                                {
                                    if (i + 1 == 1)
                                    {
                                        Econsumption += c2 * runtimepf1 * runtimepf1 + c1 * runtimepf1 + c0;
                                        runtimep1 += frequency * runtimet4 / runtimepf1;
                                    }
                                    else if (i + 1 == 2)
                                    {
                                        Econsumption += c2 * runtimepf2 * runtimepf2 + c1 * runtimepf2 + c0;
                                        runtimep2 += frequency * runtimet4 / runtimepf2;

                                    }
                                    else if (i + 1 == 3)
                                    {
                                        Econsumption += c2 * runtimepf3 * runtimepf3 + c1 * runtimepf3 + c0;
                                        runtimep3 += frequency * runtimet4 / runtimepf3;
                                    }

                                }
                                else if (m == 5)
                                {
                                    if (i + 1 == 1)
                                    {
                                        Econsumption += c2 * runtimepf1 * runtimepf1 + c1 * runtimepf1 + c0;
                                        runtimep1 += frequency * runtimet5 / runtimepf1;
                                    }
                                    else if (i + 1 == 2)
                                    {
                                        Econsumption += c2 * runtimepf2 * runtimepf2 + c1 * runtimepf2 + c0;
                                        runtimep2 += frequency * runtimet5 / runtimepf2;

                                    }
                                    else if (i + 1 == 3)
                                    {
                                        Econsumption += c2 * runtimepf3 * runtimepf3 + c1 * runtimepf3 + c0;
                                        runtimep3 += frequency * runtimet5 / runtimepf3;

                                    }

                                }





                            }


                        }


                    }
                    //找出3个线程最长的runtime
                    if (runtimep1 >= runtimep2 && runtimep1 >= runtimep3)
                    {
                        runtime = runtimep1;

                    }
                    else if (runtimep2 >= runtimep1 && runtimep2 >= runtimep3)
                    {
                        runtime = runtimep2;
                    }
                    else if (runtimep3 >= runtimep1 && runtimep3 >= runtimep2)
                    {
                        runtime = runtimep3;
                    }




                    //比较runtime 和 maxruntime
                    string[] strArray = strscsv[j].Split(new char[] { ',' });
                    //打印能量消耗
                    textBox2.Text += "ALLOCATION-ID" + strArray[1] + "EnergyConsumption：" + Econsumption + Environment.NewLine;
                    if (runtime == 0)
                    { textBox1.Text += "ALLOCATION-ID" + strArray[1] + " invalid allocation " + Environment.NewLine; }
                    else
                    {
                        textBox1.Text += "ALLOCATION-ID" + strArray[1] + " runtime: " + runtime + Environment.NewLine;
                    }

                    if (runtime > maxtime)
                    {
                        errortan++;
                        textBox1.Text += "invalid runtime" + Environment.NewLine;
                        errorlist += "Error" + errortan + ": " + "tan file " + "ALLOCATION-ID" + strArray[1] + " invalid runtime(overflow)" + Environment.NewLine;

                    }
                    else
                    {
                        if (runtime == 0)
                        {


                        }
                        else
                        {
                            textBox1.Text += "valid runtime" + Environment.NewLine;
                        }
                    }

                    //归0下一个ALLOCATION开始计算
                    Econsumption = 0;
                    runtime = 0;
                    runtimep1 = 0;
                    runtimep2 = 0;
                    runtimep3 = 0;
                }
            }



            //检测csv文件是否有效
            if (errorcsv != 0)
            {
                textBox2.Text += "error nums are  " + errorcsv + Environment.NewLine + "invalid .csv file" + Environment.NewLine;
            }
            else

            {
                textBox2.Text += "error nums are  " + errorcsv + Environment.NewLine + "valid .csv file" + Environment.NewLine + "END TEST ";

            }
            if (errortan != 0)
            {
                textBox1.Text += "error nums are  " + errortan + Environment.NewLine + "invalid .tan file" + Environment.NewLine;
            }
            else
            {
                textBox1.Text += "error nums are  " + errortan + Environment.NewLine + "valid .tan file" + Environment.NewLine;

            }

            //归零给下一个文件计算
            errortan = 0;
            errorcsv = 0;



        
            
        }

            //validate   Button
            //energy consumption formular:   10f2 - 25f + 25 

         
        private void AllocationsToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            allocation();
        }




        //view

        private void EToolStripMenuItem_Click_1(object sender, EventArgs e)
        {//设置字体
            textBox1.Font = new Font(textBox1.Font.FontFamily, 12, textBox1.Font.Style);
            textBox2.Font = new Font(textBox1.Font.FontFamily, 12, textBox2.Font.Style);
            textBox1.Text = errorlist;
            textBox2.Text = "Have a nice day!";
            errorlist = "";

        }



        //Help

        private void AboutAllocationsToolStripMenuItem_Click_1(object sender, EventArgs e)
        {//设置字体
            textBox1.Font = new Font(textBox1.Font.FontFamily, 12, textBox1.Font.Style);
            textBox2.Font = new Font(textBox1.Font.FontFamily, 12, textBox2.Font.Style);
            textBox1.Text = "plc log on clouddeakin sit323 resources week2 to find more details about allocations " + Environment.NewLine + "Thanks!" + Environment.NewLine;

        }
    }
}
